#!/usr/bin/env python3

import numpy
import scipy.io.wavfile as wave

f=open("fjaa2.txt",'r')
son=[]
for line in f:
    soni=line.split()
    if soni!=[]:
        son.append(soni[0])
lson=numpy.array(son,dtype=float)
m=max(abs(lson))
lson=2**14*lson/m
lson2=numpy.array(lson,dtype=numpy.int16)
wave.write("fjaa.wav",44100,lson2)
f.close()
print('ok')