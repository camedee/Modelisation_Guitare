from matplotlib import pyplot as plt

f=open("fjaa2.txt",'r')
sound=[f.readline()]
time=[0]
temps=0
step=1.0/44100
for line in f:
    temps+=step
    st=line.split()
    if st!=[]:
        sound.append(st[0])
        time.append(temps)
f.close()



plt.plot(time,sound)

plt.show()