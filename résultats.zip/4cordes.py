c1=open("corde1.txt",'r')
c2=open("corde2.txt",'r')
c3=open("corde3.txt",'r')
c4=open("corde4.txt",'r')
son=[]
for line in c1:
    soni=line.split()
    if soni!=[]:
        son.append(float(soni[0]))
for i in range(len(son)):
    soni=c2.readline().split()
    if soni==[]:
        while soni==[]:
            soni=c2.readline().split()
    son[i]+=float(soni[0])
    soni=c3.readline().split()
    if soni==[]:
        while soni==[]:
            soni=c3.readline().split()
    son[i]+=float(soni[0])
    soni=c4.readline().split()
    if soni==[]:
        while soni==[]:
            soni=c4.readline().split()
    son[i]+=float(soni[0])

c1.close()
c2.close()
c3.close()
c4.close()

f=open("fjaa2.txt",'w')
for i in son:
    f.write(str(i)+'\n')
f.close()
print ('termine')