#include <stdio.h>
#define freq 44100
#define duration 15
#define longueur 101

float *uc, *up, *us;


float son[freq*duration];
float Rho = 8000.0f;
float E = 3.85e8;
float Muair = 0.001f;
float Dair = 0.002f;
float Muvisc = 89.0f;
float eps = 1.4f;
float dt = 1.0f / freq;
float dx = 0.65f / (longueur - 1);
float Fmax = 10e9;
float N = 0.02f;
float N2 = 1.0f;
float N3 = 1.5f;
float s1[longueur];
float s2[longueur];
float s3[longueur];
int i0 = 10;
float saut = 1.05946309436f;
int micro1 = longueur / 8;
int micro2 = longueur / 11;
int micro3 = longueur / 9;

float tnotes[30] = { 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 7.0, 7.5, 8.0, 9.0, 9.25, 9.5, 9.75, 10.0, 10.5, 11.0, 11.25, 11.5, 11.75, 12.0, 12.5, 13.0, 13.5, 14.0, duration + 0.5f };
int posnotes[29] = { 2, 4, 6, 2, 2, 4, 6, 2, 6, 7, 9, 6, 7, 9, 9, 11, 9, 7, 6, 2, 9, 11, 9, 7, 6, 2, 4, -1, 2 };
float durenotes[29] = { 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1.0, 0.5, 0.5, 1.0, 0.375, 0.125, 0.25, 0.25, 0.5, 0.5, 0.375, 0.125, 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 1.0 };



void next(float K1, float K2, float K3){
	int i;
	for (i = 1; i<longueur - 1; ++i){
		us[i] = (K1 + K3)*uc[i + 1] + (2 - 2 * K1 - K2 - 2 * K3)*uc[i] + (K1 + K3)*uc[i - 1] + (-1 + K2 + 2 * K3)*up[i] - K3*up[i - 1]-K3*up[i+1];
	}
	float *up_back = up;
	up = uc;
	uc = us;
	us = up_back;
}

int place(int pos){
	float res;
	if (pos < 12){
		res = longueur;
		for (int i = 0; i < pos; ++i){
			res = res / saut;
		}
		return (int)res;
	}
	if (pos > 24){
		res = longueur / 4;
		for (int i = 0; i < pos - 24; ++i){
			res = res / saut;
		}
		return (int)res;
	}
	res = longueur / 2;
	for (int i = 0; i < pos - 12; ++i){
		res = res / saut;
	}
	return (int)res;
}

int jnote(int pos, float duree, float K1, float K2, float K3, int debut){
	int t = 0;
	int pos1 = place(pos);
	while (t*dt < duree){
		next(K1, K2, K3);
		if (t*dt<N && pos!=-1){
			uc[i0] += (t*dt)*Fmax*dt*dt / N / Rho;
		}
		if (pos != 0 && pos!=-1){
			if (t*dt < N){
				uc[pos1] += (t*dt)*(t*dt)*(-uc[pos1]) / N / N;
			}
			if (t*dt < duree && t*dt>N){
				uc[pos1] = 0.0;
			}
		}
		if (pos == -1){
			if (t*dt < N){
				for (int i = 0; i < longueur; ++i){
					uc[i] += up[i] - uc[i] + (t*dt)*(t*dt)*(-up[i]) / N / N;
				}
			} 
			if (t*dt > N){
				for (int i = 0; i < longueur; ++i){
					uc[i] = 0;
				}
			}
		}
		son[debut + t] = uc[micro1] + uc[micro2] + uc[micro3];
		t += 1;
	}
	return t;
}


int main(int args, char *argv[]){
	up = s1;
	uc = s2;
	us = s3;
	float K1 = eps*E*dt*dt / (Rho*dx*dx);
	float K2 = -Muair*dt / (3.1415f*Dair*Rho);
	float K3 = Muvisc*dt / (dx*dx*Rho);
	int i;
	for (i = 0; i<longueur; ++i){
		up[i] = 0.0f;
		uc[i] = 0.0f;
	}
	son[0] = 0;
	us[0] = 0;
	us[longueur - 1] = 0;
	int t=0;
	int nono = 0;
	while(t < freq*duration){
		if (t*dt >= tnotes[nono]){
			t+=jnote(posnotes[nono],durenotes[nono],K1,K2,K3,t);
			nono += 1;
		}
		else{
			next(K1, K2, K3);
			son[t] = uc[micro1] + uc[micro2] + uc[micro3];
			t += 1;
		}
	}
	for (i = 0; i<freq*duration; ++i){
		printf("%f \n", son[i]);
	}
	return 0;
}